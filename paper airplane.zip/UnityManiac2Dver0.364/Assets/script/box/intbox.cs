﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class intbox : MonoBehaviour {

    public double nextframe = 0;
    int i = 0;
    
    public int[] stageEnemy;

    /*public int[] stageEnemy1 =  {200, 300, 400, 500, 600,
                               700, 800, 900, 1000, 1100,
                               1200, 1300};*/

    public double[] stageEnemy1 =  {300.0, 350.0, 400.0,450.0, 500.0,
                             700.0, 800.0, 900.0, 1000.0, 1100.0,
                             1200.0, 1300.0};

    void Update()
    {
        if (nextframe == stageEnemy1[i])
        {
            Debug.Log(nextframe);
            Debug.Log(stageEnemy1[i]);
            i++;
        }
        nextframe++;
    }

}
