﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

 [RequireComponent(typeof(objpool))]
public class objcreate : MonoBehaviour {

     [SerializeField]private GameObject _bulletPrefab;
     private const int BULLET_MAX = 10;
     private int _state = 0;
     private float _originDirection = 0.0f;
     private bool _isReverse = false;
     private objpool _pool;


     private GameObject _target = null;
     public GameObject option;
     private GameObject op = null;
     private GameObject op1 = null;
     private GameObject op2 = null;
     private GameObject op3 = null;

     private void Awake()
     {
         _pool = GetComponent<objpool>();
         _pool.CreatePool(_bulletPrefab, BULLET_MAX);
     }

     void Update()
     {
         var ang = option.transform.rotation;
         var pos = option.transform.position;
         if (Input.GetButton("GamePad1button0"))
         {
             if (Input.GetButton("GamePad1button5"))
             {

                 if (_target == null)
                 {    //未取得であればキャッシュする
                     _target = GameObject.FindWithTag("enemy/em");
                 }
                 //的に向かって角度を変える
                 var vec = (_target.transform.position - option.transform.position).normalized;
                 var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
                 option.transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);
                 if (_state % 5 == 0)
                 {
                     var bullet = _pool.GetObject();
                     if (bullet != null){
                         bullet.GetComponent<zikiBullet>().shotInitialize(_originDirection,pos);                    
}
                     _originDirection = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg);
                     _isReverse = !_isReverse;
                 }
                 _state++;
             }
         }
         else
         {
             //通常ショット(オプション)の制御
             //各オプションの初期状態の角度
             op = GameObject.FindWithTag("option/op");
             op.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z + 30.0f);
             op1 = GameObject.FindWithTag("option/op1");
             op1.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z - 30.0f);
             op2 = GameObject.FindWithTag("option/op2");
             op2.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z + 10.0f);
             op3 = GameObject.FindWithTag("option/op3");
             op3.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z - 10.0f);

         }
    }
}


