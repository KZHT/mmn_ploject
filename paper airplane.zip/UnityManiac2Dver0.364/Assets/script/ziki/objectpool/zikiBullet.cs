﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zikiBullet : MonoBehaviour {

    private float _speed = 20.0f;
    private float _direction;
   
    private Vector3 _spawn;
    private Rigidbody2D _rigidBody;

    Vector2 oppos;
   

    public void shotInitialize(float direction, Vector3 Spawn) 
    {
        _direction = direction;
        _spawn = Spawn;
        _rigidBody = GetComponent<Rigidbody2D>();

        SetDirection();
    }

   

    public void Update()
    {
        SetDirection();
    }

    public void OnBecameInvisible()
    {
        gameObject.SetActive(false);
        ResetPosition();
    }

    private void SetDirection()
    {
        Vector2 v;
        v.x = Mathf.Cos(Mathf.Deg2Rad * _direction) * _speed;
        v.y = Mathf.Sin(Mathf.Deg2Rad * _direction) * _speed;

        _rigidBody.velocity = v; 

    }

    private void ResetPosition()
    {
       
        _rigidBody.velocity = Vector2.zero;
        //transform.localPosition = Vector3.zero;
        //transform.localPosition = _spawn;
        transform.position = _spawn;
    }
}
