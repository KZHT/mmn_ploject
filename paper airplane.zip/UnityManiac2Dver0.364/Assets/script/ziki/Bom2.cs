﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bom2 : MonoBehaviour {

    private const string MAIN_CAMERA_TAG_NAME = "MainCamera";

    private bool _isRenderd = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        Debug.Log("カメラに映ってるよ！");

        _isRenderd = false;

	}

    private void OnWillRenderObject()
    {
        if (Camera.current.tag == MAIN_CAMERA_TAG_NAME)
        {
            _isRenderd = true;

        }

    }

}
