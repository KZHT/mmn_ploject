﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bom : MonoBehaviour {

    [SerializeField]
    private float Time = 300.0f;
    [SerializeField]
    private float deltaTime = 1.0f;

    [SerializeField]
    public GameObject thisbom;
    // Update is called once per frame
    void Update()
    {
        Time -= deltaTime;


        if (Time < 0.0f )
        {
           // Destroy(this.gameObject);
            thisbom.SetActive(false);
            Time = 300.0f;
        }
    }   


}


