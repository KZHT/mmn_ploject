﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zikiGraze : MonoBehaviour
{

    public GrazeGauge graize;

    [SerializeField]
    GameObject bom;
    void Awake()
    {
        bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

    }

    void Update()
    {

        if (bom.activeSelf)
        {
            GetComponent<CircleCollider2D>().enabled = false;  
        }else
         GetComponent<CircleCollider2D>().enabled = true;
    }

    void OnTriggerEnter2D(Collider2D Graze)
    {
        if (Graze.gameObject.CompareTag("Enemy") || Graze.gameObject.CompareTag("Shot"))
        {
            Debug.Log("グレイズ！");
            if (graize.gaugecount <= 0.9)
            {
                graize.gaugecount += 0.1f;
            }
        }

    }
}
