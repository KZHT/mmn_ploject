﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zikimove : MonoBehaviour
{
    //MonoBehaviour GrazeGauge
    private float _speed = 0.1f;
    private float _speedslow = 0.07f;
    protected Vector3 playerpos;
    Vector3 shootpos;
    private static int shotdisplay = 0;
    zikicollizon collizon;
    //public UserModel user;

    public GameObject bom;
    public GrazeGauge graze;

	// Update is called once per frame
	void Update () {

        playerpos = transform.position;
        if (Input.GetButton("GamePad1button0")||Input.GetKey(KeyCode.LeftShift) )
        {

                if (playerpos.x < 4.5f)
                {
                    if (Input.GetAxisRaw("GamePad1X") > 0 || Input.GetKey(KeyCode.RightArrow))
                    {
                        playerpos.x += _speedslow;

                    }
                }

                if (playerpos.x > -4.5f)
                {
                    if (Input.GetAxisRaw("GamePad1X") < 0 || Input.GetKey(KeyCode.LeftArrow))
                    {
                        playerpos.x -= _speedslow;
                    }
                }


                if (playerpos.y < 4.5f)
                {
                    if (Input.GetAxisRaw("GamePad1Y") > 0 || Input.GetKey(KeyCode.UpArrow))
                    {
                        playerpos.y += _speedslow;
                    }
                }

                if (playerpos.y >-4.5f)
                {
                    if (Input.GetAxisRaw("GamePad1Y") < 0 || Input.GetKey(KeyCode.DownArrow))
                    {
                        playerpos.y -= _speedslow;
                    }
                }
        }
        else
        {

            if (playerpos.x < 4.5f)
            {
                if (Input.GetAxisRaw("GamePad1X") > 0 || Input.GetKey(KeyCode.RightArrow))
                {
                    playerpos.x += _speed;

                }
            }

            if (playerpos.x > -4.5f)
            {
                if (Input.GetAxisRaw("GamePad1X") < 0 || Input.GetKey(KeyCode.LeftArrow))
                {
                    playerpos.x -= _speed;
                }
            }


            if (playerpos.y < 4.5f)
            {
                if (Input.GetAxisRaw("GamePad1Y") > 0 || Input.GetKey(KeyCode.UpArrow))
                {
                    playerpos.y += _speed;
                }
            }

            if (playerpos.y > -4.5f)
            {
                if (Input.GetAxisRaw("GamePad1Y") < 0 || Input.GetKey(KeyCode.DownArrow))
                {
                    playerpos.y -= _speed;
                }
            }
        }
    transform.position = playerpos;

    if (Input.GetButton("GamePad1button5"))
    {
      
    }

    if (Input.GetKey(KeyCode.X) && graze.gaugecount == 1.0)
    {
        graze.gaugecount = 0;
        bom.SetActive(true);
        
    }


	}

    
 
}
