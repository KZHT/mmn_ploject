﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class optionBullet : MonoBehaviour {

    public int opspeed = 50;
    public int opdeathcnt = 0;
    public GameObject opshot;
	// Use this for initialization
	void Start () {
        GetComponent<Rigidbody2D>().velocity = transform.up.normalized * opspeed;
	}
	
	// Update is called once per frame
	void Update () {
		 if (opdeathcnt > 40)
        {
            Destroy(opshot);
            //lockshot.opshotdisplay--;
            opdeathcnt = 0;
        }
        else { opdeathcnt++; }
	}
	}

