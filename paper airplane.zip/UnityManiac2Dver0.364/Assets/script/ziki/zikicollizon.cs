﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class zikicollizon : MonoBehaviour
{
    [SerializeField]
   public LIFEPanel panel;
    [SerializeField]
    public UserModel user;

    [SerializeField]
    public GameObject zako;
    [SerializeField]
    public GameObject tyuu;
    [SerializeField]
    public GameObject zako2;

   // [SerializeField]
   private Shooter shooterScript ;
   // [SerializeField]
    private Shooter shooter;
   // [SerializeField]
    private Shooterenemyway shooterway;
    
    public int life = 3;
    public int lifecnt =0;

    public bool clear = true;
   

    void Update()
    {     
            panel.UpdateLife(life);

        //無敵判定(当たり判定を表示非表示)
            if (lifecnt > 0)
            { lifecnt--; }
            else
            {
                GetComponent<CircleCollider2D>().enabled = true;
                Debug.Log("collider_true");
            }
            
    }

   void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.CompareTag("Enemy") || collider.gameObject.CompareTag("Shot"))
        { 
            //Debug.Log("グハァ！");
            lifecnt = 400;
            life -= 1;
            GetComponent<CircleCollider2D>().enabled = false;
            Debug.Log("collider_false");
           this.transform.localPosition = new Vector3(0, -4.0f, 0);
        }

    }

  

}
