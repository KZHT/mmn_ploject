﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class instance : MonoBehaviour {

    public GameObject ziki;

	// Use this for initialization
	void Start () {
        Instantiate(ziki, new Vector2(0.0f,-1.0f), new Quaternion(0.0f,0.0f,0.0f,0.0f));
	}
	
	
}
