﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PoolableObject : MonoBehaviour {

	//使い終わったら戻すためにプールへの参照を持ちます。
    public GenericPool Pool { private get; set; }

    // start()が呼べないのでInitを別途実装します。
    public abstract void Init();

    //プールに戻します

    protected new void Destroy(Object obj)
    {
        ReturnToPool();
    }

    //プールに戻します
    protected void ReturnToPool()
    {
      Pool.Return(this);
    }


}
