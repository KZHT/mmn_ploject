﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[RequireComponent(typeof(Rigidbody2D),typeof(Collider2D))]
public class tama : PoolableObject{

    [SerializeField]
    private Rigidbody2D Rigidbody;

    [SerializeField]
    protected Vector2 Velocity;

    public override void Init()
    {
        //移動速度を設定する
        Rigidbody.velocity = Velocity;
    }

    void Update()
    {
        //上に向かって進むので、y>5になったらプールに戻す。
        if(transform.position.y > 5f)
        {
            ReturnToPool();
        }
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        //何かにぶつかったらプールに戻す
        ReturnToPool();
    }

}
