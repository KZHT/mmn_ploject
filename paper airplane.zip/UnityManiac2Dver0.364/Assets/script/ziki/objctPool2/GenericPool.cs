﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class GenericPool : MonoBehaviour
{
 //ここにプールしたいPrefabをエディタで指定
    [SerializeField]
    private PoolableObject PooledObject;

    //プールサイズを指定しておきます(メモリ節約)
    //必要に応じて調整してください。
    private const int PoolSize = 50;

    //プールの実態。Queueを使用します。
    private readonly Queue<PoolableObject> _pool
                                      = new Queue<PoolableObject>(PoolSize);

    //どうでもいい定数。あんまり回転いじらないのでゼロを作ってるだけ。
    private static readonly Quaternion NoRotation = Quaternion.Euler(0, 0, 0);


    //プールにオブジェクトがあればそれを利用します。
    //無ければ新たにオブジェクトをInstantiateします。

    public T Place<T>(Vector2 position) where T : PoolableObject
    {
        return (T)Place(position);
    }

    //プールにオブジェクトがあればそれを利用します。
    //無ければ新たにオブジェクトをInstantiateします。

    public PoolableObject Place(Vector2 position)
    {
        PoolableObject obj;

        if(_pool.Count > 0)
        {
            obj = _pool.Dequeue();
            obj.gameObject.SetActive(true);
            obj.transform.position = position;
            obj.Init();

        }
        else
        {
            obj = Instantiate(PooledObject, position, PooledObject.transform.rotation);
            obj.Pool = this;
            obj.Init();
        }
        return obj;
    }

    //オブジェクトをプールに戻します

    public void Return(PoolableObject obj)
    {
        obj.gameObject.SetActive(true);
        _pool.Enqueue(obj);
    }
}
