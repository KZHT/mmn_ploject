﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bulletmain : MonoBehaviour {
    public int speed = 50;
    public int deathcnt = 0;
    public GameObject mainshot;
	// Use this for initialization

	
	// Update is called once per frame
	void Update () {
        if (deathcnt > 40)
        {
            Destroy(mainshot);
           // zikishoot.shotdisplay--;
            deathcnt = 0;
        }
        else { deathcnt++; }
	}
}
