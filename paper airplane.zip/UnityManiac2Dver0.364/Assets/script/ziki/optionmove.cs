﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class optionmove : zikimove {

    private GameObject _target = null;
    private GameObject _ziki = null;
    public GameObject option;
    Vector3 zikipos;
    Vector3 OPpos;

    private GameObject op = null;
    private GameObject op1 = null;
    private GameObject op2 = null;
    private GameObject op3 = null;
    int anicnt = 0;
    // Update is called once per frame
    //狙い撃ち角度を取得

    void Start()
    {
        _ziki = GameObject.FindWithTag("Player");
        op = GameObject.FindWithTag("option/op");
        op1 = GameObject.FindWithTag("option/op1");
        op2 = GameObject.FindWithTag("option/op2");
        op3 = GameObject.FindWithTag("option/op3");
    }

    void Update(){
        zikipos = _ziki.transform.position;
       // opang();
        oppos();
	}

  /*  private void opang()
    {
       
        if (Input.GetButton("GamePad1button0") || Input.GetKey(KeyCode.LeftShift))
        {

            if (Input.GetButton("GamePad1button5") || Input.GetKey(KeyCode.Z))
            {
               
            }

        }
        else
        {//通常ショット(オプション)の制御
            //各オプションの初期状態の角度
            
          
         
            
            
           
           

         
            
           
            
          
            
         

            if (Input.GetButton("GamePad1button5"))
            {

                if (opshotdisplay <= 40)
                {

                    // Instantiate(optionBullet, transform.position, transform.rotation);
                    opshotdisplay++;
                }
            }
        }

    }*/

    private void oppos()
    {
        var ang = option.transform.rotation;

        if (Input.GetButton("GamePad1button0") || Input.GetKey(KeyCode.LeftShift))
        {

            if (anicnt > 7)
            {
                op.transform.position = new Vector3(_ziki.transform.position.x - 1.0f, _ziki.transform.position.y);
                op1.transform.position = new Vector3(_ziki.transform.position.x + 1.0f, _ziki.transform.position.y);
                op2.transform.position = new Vector3(_ziki.transform.position.x - 0.5f, _ziki.transform.position.y);
                op3.transform.position = new Vector3(_ziki.transform.position.x + 0.5f, _ziki.transform.position.y);
                if (_target == null)
                {
                    //未取得であればキャッシュする
                    _target = GameObject.FindWithTag("enemy/rock");
                    Debug.Log("ターゲット取得しました。");
                }
                else
                {
                    if (_target.transform.position.x == 6f || _target.transform.position.y == 6f)
                        _target = null;
                }
                //敵に向かって角度を変える 
                var vec = (_target.transform.position - option.transform.position).normalized;
                var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
                option.transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);
            }
            else
            {
                op.transform.Translate(-0.001f, 0.01f, 0);
                op1.transform.Translate(0.001f, 0.01f, 0);
                op2.transform.Translate(-0.0025f, 0.02f, 0);
                op3.transform.Translate(0.0025f, 0.02f, 0);
                anicnt++;
            }

            

        }
        else{
            op.transform.position = new Vector3(_ziki.transform.position.x - 0.6f, _ziki.transform.position.y - 0.3f);
            op.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z + 30.0f);
            op1.transform.position = new Vector3(_ziki.transform.position.x + 0.6f, _ziki.transform.position.y - 0.3f);
            op1.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z - 30.0f);
            op2.transform.position = new Vector3(_ziki.transform.position.x - 0.25f, _ziki.transform.position.y - 0.75f);
            op2.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z + 10.0f);
            op3.transform.position = new Vector3(_ziki.transform.position.x + 0.25f, _ziki.transform.position.y - 0.75f);
            op3.transform.rotation = Quaternion.Euler(0.0f, 0.0f, ang.z - 10.0f);
            anicnt = 0;
        }
    }


}
