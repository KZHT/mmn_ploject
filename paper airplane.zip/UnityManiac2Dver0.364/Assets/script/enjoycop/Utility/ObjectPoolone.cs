﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectPoolone<T> where T : CachedBehaviour {
    //各オブジェクトの共有設定
    private struct ObjectParam
    {
        public Object prefab;  //元のprefab
        public Transform root; //生成した親ノード
        public T[] pool;       //空きオブジェクトバッファ
        public int freeIndex;  //空きオブジェクトインデックス
        public int genMax;     //生成限界数
        public int genCount;   //生成した数
    }

    private int category = 0;               //オブジェクトのカテゴリ
    private int typeCount = 0;              //オブジェクト種類数
    private ObjectParam[] objParams = null; //オブジェクト情報
    private T[][] objList = null;           //全オブジェクトリスト
    //private TaskSystem<T> activeObjTask = null; //稼働オブジェクトタスク

}
