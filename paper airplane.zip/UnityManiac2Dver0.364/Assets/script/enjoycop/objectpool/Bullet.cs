﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {

    private float _speed = 4.0f;
    private float _direction;
    private bool _isReverse;
    private Rigidbody2D _rigidBody;

    public void Initialize(float direction, bool isReverse)
    {
        _direction = direction;
        _isReverse = isReverse;
        _rigidBody = GetComponent<Rigidbody2D>();


        SetDirection();
    }

    public void Update()
    {
       
        SetDirection();
    }

    public void OnBecameInvisible()
    {
        gameObject.SetActive(false);
        ResetPosition();
    }

    private void SetDirection()
    {
        Vector2 v;
        v.x = Mathf.Cos(Mathf.Deg2Rad * _direction) * _speed;
        v.y = Mathf.Sin(Mathf.Deg2Rad * _direction) * _speed;

        _rigidBody.velocity = v; 
    }

    private void ResetPosition()
    {
        _rigidBody.velocity = Vector2.zero;　
        transform.localPosition = Vector3.zero;
    }

}
