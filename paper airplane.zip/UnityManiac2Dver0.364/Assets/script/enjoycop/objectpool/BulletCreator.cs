﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(ObjectPool))]
public class BulletCreator : MonoBehaviour {

    [SerializeField] private GameObject _bulletPrefab;
    private const int BULLET_MAX = 10;
    private int _state = 0;
    private float _originDirection = 0.0f;
    private bool _isReverse = false;
    private ObjectPool _pool;

    private void Awake()
    {
        _pool = GetComponent<ObjectPool>();
        _pool.CreatePool(_bulletPrefab, BULLET_MAX);
    }

    //Update is called once per frame
    void Update()
    {
        if (_state % 30 == 0)
        {
            var way = 1; //16方向
            for (int i = 0; i < way; i++){

                var bullet = _pool.GetObject();
                if (bullet != null){
                    bullet.GetComponent<Bullet>().Initialize(_originDirection + i * (360.0f / way), _isReverse);　
                }
            }
            //_originDirection = (_originDirection + 10) % 360;
            _originDirection = _originDirection % 360;
            _isReverse =! _isReverse;
        }

        _state++;
    }

}
