﻿using UnityEngine;
using UnityEditor;

//MissilePrefabカタログ
[CustomEditor(typeof(MissileCatalog))]
public sealed class MissileCatalogEditor : AssetCatalogEditor<GameObject, MISSILE> { }
//[CustomEditor(typeof(OPMissileCatalog))]
//public sealed class OPMissileCatalogEditor : AssetCatalogEditor<GameObject, OPMISSILE> { }