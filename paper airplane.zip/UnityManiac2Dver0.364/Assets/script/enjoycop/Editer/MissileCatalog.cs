﻿using UnityEngine;

//ミサイル種類
public enum MISSILE
{
    UP,　　　//スタート地
    RIGHT,
    DOWN,
    OPLEFT1,　//場所入れ替え
    OPLEFT2,  //場所入れ替え
    OPRIGHT1, //場所入れ替え
    OPRIGHT2, //場所入れ替え
    LEFT,　　// ゴール地
    
   

    MAX,
}

/*public enum OPMISSILE
{
    OPLEFT1,
    OPLEFT2,
    OPRIGHT1,
    OPRIGHT2,

    MAX,
}*/


//ミサイルカタログ
[CreateAssetMenu(menuName = "Catalog/Missile")]
public sealed class MissileCatalog : AssetCatalog { }

//[CreateAssetMenu(menuName= "Catalog/OPMissile")]
//public sealed class OPMissileCatalog : AssetCatalog { }