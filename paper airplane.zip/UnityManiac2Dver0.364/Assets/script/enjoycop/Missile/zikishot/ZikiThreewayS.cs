﻿using UnityEngine;

public class ZikiThreewayS : Missile2D
{
    public override void Ignition()
    {
       this.direct = new Vector3(0, 50, 0);
    }
	
}
