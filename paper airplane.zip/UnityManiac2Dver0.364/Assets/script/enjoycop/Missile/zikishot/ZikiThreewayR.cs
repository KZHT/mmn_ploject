﻿using UnityEngine;

public class ZikiThreewayR : Missile2D
{

    public override void Ignition()
    {
        this.direct = new Vector3(10, 50, 0);
    }
}
