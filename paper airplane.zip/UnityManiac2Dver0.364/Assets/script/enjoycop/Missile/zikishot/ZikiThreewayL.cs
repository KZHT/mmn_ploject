﻿using UnityEngine;

public class ZikiThreewayL : Missile2D
{

    public override void Ignition()
    {
        this.direct = new Vector3(-10, 50, 0);
    }
}
