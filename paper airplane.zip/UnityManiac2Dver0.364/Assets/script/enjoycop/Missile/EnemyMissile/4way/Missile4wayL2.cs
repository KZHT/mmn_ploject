﻿using UnityEngine;

public class Missile4wayL2 : Missile2D
{

    public override void Ignition()
    {
        this.direct = new Vector3(-5, -10, 0);
    }
}
