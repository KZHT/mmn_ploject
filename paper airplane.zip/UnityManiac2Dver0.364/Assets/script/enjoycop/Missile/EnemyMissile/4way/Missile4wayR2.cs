﻿using UnityEngine;

public class Missile4wayR2 : Missile2D
{
    public override void Ignition()
    {
        this.direct = new Vector3(5, -10, 0);
    }
	
}
