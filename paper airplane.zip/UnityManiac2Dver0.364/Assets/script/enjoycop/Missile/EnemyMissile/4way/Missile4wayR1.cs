﻿using UnityEngine;

public class Missile4wayR1 : Missile2D
{

    public override void Ignition()
    {
        this.direct = new Vector3(10, -10, 0);
    }
}
