﻿using UnityEngine;

public class Missile4wayL1 : Missile2D
{

    public override void Ignition()
    {
        this.direct = new Vector3(-10, -10, 0);
    }
}
