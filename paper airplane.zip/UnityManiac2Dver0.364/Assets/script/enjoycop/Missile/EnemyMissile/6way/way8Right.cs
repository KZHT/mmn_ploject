﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class way8Right : Missile2D
{
    private float way8 = -10;

    public override void Ignition()
    {
        if (way8 < 10)
        {
            way8 += 5;

        }
        else
            way8 = -10;
        this.direct = new Vector3(20, way8, 0);
    }

}
