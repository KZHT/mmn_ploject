﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile2wayLeft : Missile2D
{
    private GameObject _target = null;

    private GameObject _pos = null;

    //速度
    private Vector3 posspd = new Vector3(2f, 2f);
    //ラジアン変数
    private float rad;

    //現在位置を代入する為の変数
    private Vector3 Position;

    // Use this for initialization
    void Start()
    {

        _pos = this.gameObject;
        if (_target == null)
        {
            _target = GameObject.FindWithTag("Player");
            Debug.Log("Playerロックオン");
        }
        else
        {
            if (_target.transform.position.x == 6f || _target.transform.position.y == 6f)
                _target = null;
        }

        transform.position = _pos.transform.position;
        //角度
        var vec = (_target.transform.position - transform.position).normalized;
        var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
        transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);

        //ターゲット座標取得
        rad = Mathf.Atan2(
           _target.transform.position.y - transform.position.y,
            _target.transform.position.x - transform.position.x);

        Position = transform.position;

        this.direct.x += posspd.x * Mathf.Cos(rad - 0.4f);
        this.direct.y += posspd.y * Mathf.Sin(rad - 0.4f);

        transform.position = Position;


    }

    // Update is called once per frame
    void Update()
    {


        if (Anglbool == true)
        {
            if (_target == null)
            {
                _target = GameObject.FindWithTag("Player");
                Debug.Log("Enemyロックオン");
            }
            else
            {
                if (_target.transform.position.x == 6f || _target.transform.position.y == 6f)
                    _target = null;
            }

            transform.position = _pos.transform.position;

            var vec = (_target.transform.position - transform.position).normalized;
            var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
            transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);

            rad = Mathf.Atan2(
                _target.transform.position.y - transform.position.y,
                _target.transform.position.x - transform.position.x);
            Anglbool = false;
        }

        Position = transform.position;

        this.direct.x += posspd.x * Mathf.Cos(rad - 0.2f);
        this.direct.y += posspd.y * Mathf.Sin(rad - 0.2f);

        transform.position = Position;
    }

    public override void Ignition()
    {
        this.direct = transform.position;
    }
}
