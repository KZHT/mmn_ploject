﻿using UnityEngine;

public abstract class Missile2D : CachedBehaviour {
    //↓追加　最大移動距離
    private const float LIMIT_DIST = 5f;

    protected SpriteRenderer spRender = null;

    //修正privateからprotected
    protected Vector3 direct = Vector3.down;
   
    protected float speed = 0.2f;

    protected bool Anglbool;
   
    protected int threeway;
    protected float way = 0;
   
    //オブジェクトが生成される際の処理
    //GetComponentやnew等メモリアロケートの処理を主に行う
    protected override void OnCreate()
    {
        this.spRender = this.GetComponent<SpriteRenderer>();
    }

    //オブジェクトが破壊される際の処理
    //MaterialやMesh等を生成した場合は忘れずにDestroyする
    protected override void OnRelease(){}

    //オブジェクトが呼び出された際の処理
    //共通パラメータ等の初期化を行う
    protected override void OnAwake(int no)
    {
        //稼働No.をプライオリティにして後発の弾が手前
        this.spRender.sortingOrder = no;    
    }

    //オブジェクトが回収された際の処理
    protected override void OnSleep(){}　//<-これ何？

    //更新処理
    //no : タスクNo.
    //elapsedTime : 経過時間
    protected override bool OnRun(int no, float elapsedTime){
        //↓追加稼動No.をプライオリティにして後発の弾が手前
        this.spRender.sortingOrder = no;
        
        Vector3 point = this.trans_.localPosition;

        point += this.direct * (this.speed * elapsedTime);

        //一定距離進んだら回収
        if (Mathf.Abs(point.x) > LIMIT_DIST)
        {
            Anglbool = true;
            
            return false;
        
        }
        if (Mathf.Abs(point.y) > LIMIT_DIST)
        {
            Anglbool = true;

            return false;
        }
        
        //移動継続
        this.trans_.localPosition = point;
        return true;
    }

    //点火
    public abstract void Ignition();

}
