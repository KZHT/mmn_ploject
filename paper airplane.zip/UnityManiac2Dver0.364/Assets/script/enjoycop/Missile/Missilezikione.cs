﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missilezikione : Missile2D {

    private Vector3 posspeed = new Vector3(2f, 2f);

    private float rad = 1.55f;

    private Vector3 Position;

	// Update is called once per frame
	void Update () {
        Position = transform.position;
        this.direct.x += posspeed.x * Mathf.Cos(rad);
        this.direct.y += posspeed.y * Mathf.Sin(rad);
        transform.position = Position;
	}

    public override void Ignition()
    {
        this.direct = transform.position;
    }

}
