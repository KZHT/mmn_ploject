﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Missile8way : Missile2D{

    public override void Ignition()
    {
        //MissileAllDirections MiAd = GetComponent<MissileAllDirections>();


      //  this.direct = new Vector3(MiAd.way8, -30, 0);
      //  Debug.Log(MiAd.way8);
       
    
    }
}
