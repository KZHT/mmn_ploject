﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileRight : Missile2D
{
    //ターゲット
    private GameObject target;

    private GameObject gunpos;
    //速度
    private Vector3 posspeed = new Vector3(1f, 1f);

    private float gunposx;
    private float gunposy;

    private float zikix;
    private float zikiy;
    //ラジアン変数
    private float rad;

    //現在位置を代入する為の変数
    private Vector3 Position;

    void Start()
    {
//        target = GameObject.FindWithTag("Player");
        target = GameObject.FindWithTag("Enemy");

        }
   
    void Update()
    {
        if (Anglbool == true)
        {
            rad = Mathf.Atan2(
               target.transform.position.y - transform.position.y,
                target.transform.position.x - transform.position.x);
            Anglbool = false;
        }

        Position = transform.position;

        this.direct.x += posspeed.x * Mathf.Cos(rad);
        this.direct.y += posspeed.y * Mathf.Sin(rad);

        transform.position = Position;


    }

    public override void Ignition()
    {
       this.direct = transform.position; 
     }
}
