﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileLeft : Missile2D{
    public override void Ignition()
    {
        this.direct = Vector3.left;
    }
}
