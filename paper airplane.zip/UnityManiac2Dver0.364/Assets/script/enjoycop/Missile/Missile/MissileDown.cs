﻿using UnityEngine;

public class MissileDown : Missile2D
{
    
    
    public override void Ignition()
    {
        float randomx = Random.Range(-20f,20f);
        float randomy = Random.Range(-5f, -20f);
        
        
        this.direct = new Vector3(randomx,randomy,0);
     
    }
	
}
