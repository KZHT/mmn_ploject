﻿using UnityEngine;

public class MissileUp : Missile2D {
    
    public override void Ignition()
    {

        this.direct = new Vector3(0, 50, 0);
    }

}
