﻿using UnityEngine;

public class Shooterplayer : MonoBehaviour {
    [SerializeField]
    private MissileCatalog missileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0;
   

	public void Start () 
    {
        //プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        //オブジェクトの生成
        this.pool.Generate();
	}

    public void OnDestroy()
    {
        this.pool.Final();

    }
	
	void Update () {

        if (Input.GetKeyDown(KeyCode.Space))
            this.pool.Clear();


        this.pool.FrameTop();


        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;

        float span = 0.01f;
        if(this.calcTime >= span)
        {
            Missile2D missile;

            Vector3 point = this.transform.localPosition;


            //if (Input.GetKeyDown(KeyCode.Z) 
           // if (this.pool.AwakeObject((int)this.nextType, point, out missile))

            if (Input.GetKey(KeyCode.Z) && this.pool.AwakeObject((int)this.nextType, point, out missile))
                    missile.Ignition();


                    if (this.nextType == MISSILE.LEFT)
                        this.nextType = MISSILE.UP;
                    else
                        ++this.nextType;
            this.calcTime -= span;

            }
        this.pool.Proc(elapsedTime);
    }
}
