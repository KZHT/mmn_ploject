﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShooterBoss3way : MediumbossStatus
{
    [SerializeField]
    private MissileCatalog missileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0;

    private int cntM3way1 = 0;
    private int cntM3way2 = 0;

    /*[SerializeField]
    GameObject bom;

    void Awake()
    {
        bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

    }*/

    public void Start()
    {

        // プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        // オブジェクトの生成
        this.pool.Generate();
    }
    public void OnDestroy()
    {
        this.pool.Final();
    }
    public void Update()
    {



        // スペースキーで一括回収

        /*if (bom.activeSelf || BossHitPoint > 100)
        {
            this.pool.Clear();

        }*/

       /* if (MBossHitPoint < 300)
        {
            this.pool.Clear();

        }*/
        // アクティブなオブジェクト数の更新
        // 呼び出されたフレームで経過時間0秒で処理されていたものを通常稼動扱いにする
        this.pool.FrameTop();

        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;
        // とりあえず0.01秒毎に発射
        float span = 0.01f;
        if (this.calcTime >= span)
            if (this.calcTime >= span)
            {
                Missile2D missile;

                Vector3 point = this.transform.localPosition;


                if (cntM3way2 <= 300)
                {
                    if (cntM3way1 < 3 && this.pool.AwakeObject((int)this.nextType, point, out missile))
                    {
                        missile.Ignition();

                        if (this.nextType == MISSILE.LEFT)
                            this.nextType = MISSILE.UP;
                        else
                            ++this.nextType;

                        cntM3way1++;
                    }
                    if (cntM3way2 > 299)
                    {
                        {
                            cntM3way1 = 0;
                            cntM3way2 = 0;
                            this.nextType = MISSILE.UP;
                        }
                    }
                    cntM3way2++;
                }




                this.calcTime -= span;

            }
        this.pool.Proc(elapsedTime);

    }
    
}
