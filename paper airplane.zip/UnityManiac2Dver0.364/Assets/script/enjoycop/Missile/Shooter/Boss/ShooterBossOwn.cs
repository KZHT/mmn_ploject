﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShooterBossOwn : BossStatus
{

    [SerializeField]
    private MissileCatalog missileCatalog = null;
    // private OPMissileCatalog opmissileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0f;

    private int zikicnt = 300;

   /* [SerializeField]
    GameObject bom;

    void Awake()
    {
        bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

    }*/

    public void Start()
    {

        // プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        // オブジェクトの生成
        this.pool.Generate();
    }
    public void OnDestroy()
    {
        this.pool.Final();
    }
    public void Update()
    {



        // スペースキーで一括回収

        /*if (bom.activeSelf || BossHitPoint > 100)
        {
            this.pool.Clear();

        }*/

        if (BossHitPoint < 100)
        {
            this.pool.Clear();

        }
        // アクティブなオブジェクト数の更新
        // 呼び出されたフレームで経過時間0秒で処理されていたものを通常稼動扱いにする
        this.pool.FrameTop();

        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;
        // とりあえず0.01秒毎に発射
        float span = 3.0f;
        if (this.calcTime >= span)
        {
            // プールから取り出して点火
            Missile2D missile;
            // ※Transformキャッシュを本来はすべき
            Vector3 point = this.transform.localPosition;
            if (this.pool.AwakeObject((int)this.nextType, point, out missile))

                //点火
                missile.Ignition();

            // 上下左右と順番
            if (this.nextType == MISSILE.LEFT) //最後に起動したのが左だと
                this.nextType = MISSILE.UP;    //上にリセットされる
            else
                ++this.nextType;               //じゃなかったら次のtypeが動く  例 UP→RIGHT→DOWN→LEFT　またUPへリセット
            this.calcTime -= span;
        }

        // アクティブなオブジェクトの更新
        this.pool.Proc(elapsedTime);
    }

   
 
}
