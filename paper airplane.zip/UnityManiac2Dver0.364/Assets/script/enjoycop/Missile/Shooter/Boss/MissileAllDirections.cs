﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileAllDirections : BossStatus
{
    [SerializeField]
    private MissileCatalog missileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0;
    [SerializeField]
    public float way8 = -10;

    //[SerializeField]
    //GameObject bom;

    /*[SerializeField]
    private int spawncnt = 500;

    void Awake()
    {
        bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

    }*/

    
    public void Start()
    {
        //プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        //オブジェクトの生成
        this.pool.Generate();
    }

    public void OnDestroy()
    {
        this.pool.Final();

    }

    void Update()
    { 
        /*if (bom.activeSelf || BossHitPoint < 100)
        {
            this.pool.Clear();

        }*/
        if (BossHitPoint > 100)
         this.pool.Clear(); 

            this.pool.FrameTop();
        

        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;

        float span = 0.025f;
        if (this.calcTime >= span)
        {
            Missile2D missile;

            Vector3 point = this.transform.localPosition;

            if (this.pool.AwakeObject((int)this.nextType, point, out missile))
                missile.Ignition();

            if (this.nextType == MISSILE.LEFT)
                this.nextType = MISSILE.UP;
            else
                ++this.nextType;

          

            this.calcTime -= span;

        }
        this.pool.Proc(elapsedTime);

    }
}
