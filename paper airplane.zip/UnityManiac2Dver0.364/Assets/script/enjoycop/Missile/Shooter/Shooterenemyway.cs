﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooterenemyway : MonoBehaviour
{        //MonoBehaviour  zikicollizon
    [SerializeField]
    private MissileCatalog missileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0;

    private int cnt4way1 = 0;
    private int cnt4way2 = 0;

    private int zikicnt = 300;
   
    [SerializeField] 
    GameObject bom;
  

   void Awake()
   {
       bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

   }

    public void Start()
    {
        
        // grazegauge = UIgauge.GetComponent<GrazeGauge>();
        //プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        //オブジェクトの生成
        this.pool.Generate();
    }

    public void OnDestroy()
    {
        this.pool.Final();

    }

    void Update()
    {
        if (bom.activeSelf)
        {
            this.pool.Clear();
           
        }
                
           


        this.pool.FrameTop();


        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;

        float span = 0.01f;
        if (this.calcTime >= span)
        {
            Missile2D missile;

            Vector3 point = this.transform.localPosition;


            if (cnt4way2 <= 100)
            {
                if (cnt4way1 < 4 && this.pool.AwakeObject((int)this.nextType, point, out missile))
                {
                    missile.Ignition();

                    if (this.nextType == MISSILE.LEFT)
                        this.nextType = MISSILE.UP;
                    else
                        ++this.nextType;
                   
                    cnt4way1++;
                }
                if (cnt4way2 > 99)
                {
                    {
                        cnt4way1 = 0;
                        cnt4way2 = 0;
                        this.nextType = MISSILE.UP;
                    
                    }
                }
                
                cnt4way2++;
            }




            this.calcTime -= span;

        }
        this.pool.Proc(elapsedTime);

    }



    

}
