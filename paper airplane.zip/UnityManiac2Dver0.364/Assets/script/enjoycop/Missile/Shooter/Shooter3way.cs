﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter3way : MonoBehaviour
{
    [SerializeField]
    private MissileCatalog missileCatalog = null;

    private ObjectPool<Missile2D> pool = new ObjectPool<Missile2D>();
    private MISSILE nextType = MISSILE.UP; //スタート地
    private float calcTime = 0;

    private int cnt3way1 = 0;
    private int cnt3way2 = 0;


   // [SerializeField]
   // GameObject bom;

   /* void Awake()
    {
        bom = GameObject.Find("koObj").transform.Find("Bom").gameObject;

    }*/

    public void Start()
    {
        //プール内バッファ生成
        this.pool.Initialize(0, this.missileCatalog);

        //オブジェクトの生成
        this.pool.Generate();
    }

    public void OnDestroy()
    {
        this.pool.Final();

    }

    void Update()
    {
        //if (bom.activeSelf)
       // {
          //  this.pool.Clear();
            
       // }
        
      

        this.pool.FrameTop();


        float elapsedTime = Time.deltaTime;
        this.calcTime += elapsedTime;

        float span = 0.01f;
        if (this.calcTime >= span)
        {
            Missile2D missile;

            Vector3 point = this.transform.localPosition;

         
                if (cnt3way2 <= 300)
                {
                    if (cnt3way1 < 3 && this.pool.AwakeObject((int)this.nextType, point, out missile))
                    {
                        missile.Ignition();

                        if (this.nextType == MISSILE.LEFT)
                            this.nextType = MISSILE.UP;
                        else
                            ++this.nextType;
                     
                        cnt3way1++;
                    }
                    if (cnt3way2 > 299)
                    {
                        {
                            cnt3way1 = 0;
                            cnt3way2 = 0;
                            this.nextType = MISSILE.UP;
                        }
                    }
                    cnt3way2++;
                }
         
            
            
            
            this.calcTime -= span;

        }
        this.pool.Proc(elapsedTime);

    }
    
}
