﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileOP : Missile2D {

    //ターゲット
    private GameObject target = null;

    private GameObject gunpos = null;
    //速度
    private Vector3 posspeed = new Vector3(1f, 1f);

    private float gunposx;
    private float gunposy;

    private float zikix;
    private float zikiy;
    //ラジアン変数
    private float rad;

    //現在位置を代入する為の変数
    private Vector3 Position;

    void Start()
    {
      /*  if (target == null)
        {
            target = GameObject.FindWithTag("Enemy");
            Debug.Log("ターゲット取得しました。");
        }

        gunpos = GameObject.FindWithTag("option/op");
        transform.position = gunpos.transform.position;

        //角度
        var vec = (target.transform.position - transform.position).normalized;
        var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
        transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);

        //ターゲット座標取得
        rad = Mathf.Atan2(
           target.transform.position.y - transform.position.y,
            target.transform.position.x - transform.position.x);

        Position = transform.position;

        this.direct.x += posspeed.x * Mathf.Cos(rad);
        this.direct.y += posspeed.y * Mathf.Sin(rad);

        transform.position = Position;
        */
    }

    void Update()
    {
        if (Anglbool == true)
        {
            if (target == null) 
            {
                target = GameObject.FindWithTag("Enemy");
                Debug.Log("ターゲット取得しました。");
            }
            gunpos = GameObject.FindWithTag("option/op");
            //gunpos = GameObject.FindWithTag("Player");
           transform.position = gunpos.transform.position;
            //角度
            var vec = (target.transform.position - transform.position).normalized;
            var angle = (Mathf.Atan2(vec.y, vec.x) * Mathf.Rad2Deg) - 90f;
            transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);

            //ターゲット座標取得
            rad = Mathf.Atan2(
               target.transform.position.y - transform.position.y,
                target.transform.position.x - transform.position.x);
           //これがないと常に自機を向いてしまう
            Anglbool = false;
        }

        Position = transform.position;

        this.direct.x += posspeed.x * Mathf.Cos(rad);
        this.direct.y += posspeed.y * Mathf.Sin(rad);

        transform.position = Position;


    }

    public override void Ignition()
    {
        this.direct = transform.position;
    }
}
