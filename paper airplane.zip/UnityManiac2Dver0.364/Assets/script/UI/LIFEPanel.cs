﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LIFEPanel : MonoBehaviour {

    public GameObject[] LifeIcon;


    
    public void UpdateLife(int panel1)
    {
        for (int i = 0; i < LifeIcon.Length; i++)
        {
            if (i < panel1) LifeIcon[i].SetActive(true);
            else LifeIcon[i].SetActive(false);
        }

    }

}
