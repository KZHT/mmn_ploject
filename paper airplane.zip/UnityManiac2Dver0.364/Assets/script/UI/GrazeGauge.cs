﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GrazeGauge : MonoBehaviour {

    [SerializeField]
    public Slider UIgauge;
    [SerializeField]
    public float gaugecount = 0;
    [SerializeField]
    private float gaugeClac;
    GameObject gameManager;

	
    void Update()
    {
        UIgauge.value = gaugecount;
    }

}
