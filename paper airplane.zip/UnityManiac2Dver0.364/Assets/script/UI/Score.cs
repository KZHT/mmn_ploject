﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour {
    //スコアテキスト表示
    public Text scoreText;
    //ハイスコアテキスト表示
    public Text highScoreText;

    private int score;

    private int highScore;
    //PlayerPrefsで保存するためのキー
    private string highScoreKey = "highScore";

    void Start()
    {
        Initialize();
    }

    void Update()
    {
        if (highScore < score)
        {
            highScore = score;
        }

        scoreText.text = score.ToString();
        highScoreText.text = highScore.ToString();


    }

    private void Initialize()
    {
        //スコアを0にする
        score = 0;

        //ハイスコアを取得する。保存されてなければ0を取得する。
        highScore = PlayerPrefs.GetInt(highScoreKey, 0);
    }

    //スコアの追加
    public void AddScore(int addscore)
   {
       score = score + addscore;

   }

    public void ScoreSave()
    {
        PlayerPrefs.SetInt(highScoreKey, highScore);
        PlayerPrefs.Save();

        //ゲーム開始前の状態に戻す
        Initialize();
    }

}
