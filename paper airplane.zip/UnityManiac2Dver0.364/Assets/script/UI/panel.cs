﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class panel : MonoBehaviour {
    public GameObject[] Icon;

    public void UpdateIcon(int panel)
    {
        for(int i = 0; i < Icon.Length; i++)
        {
            if (i < panel)
            {
                Icon[i].SetActive(true);
            }
            else
            {
                Icon[i].SetActive(false);
            }
            }
    }
	
}
