﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class bulletangle : MonoBehaviour {

   
    private GameObject Player;
  //  private int speed = 10;

    //速度
    private Vector3 speed = new Vector3(0.05f, 0.05f);

    //ラジアン変数
    private float rad;

    //現在位置を代入する為の変数
    private Vector3 Position;

    private float Time = 600.0f;
    private float deltaTime = 1.0f;
    private bool instcnt = false;
     

	void Start () {

        Player = GameObject.FindWithTag("Player");
        rad = Mathf.Atan2(
               Player.transform.position.y - transform.position.y,
                Player.transform.position.x - transform.position.x);
    }

    void Update()
    {
        Time -= deltaTime;
        if (Time < 0.0f)
        {

            //Destroy(this.gameObject);
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);

        }
        else
        {
            Position = transform.position;

            Position.x += speed.x * Mathf.Cos(rad);
            Position.y += speed.y * Mathf.Sin(rad);

            transform.position = Position;
        }
    }
}
