﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tyuupattarn1 : tyuu01 {

	
	// Update is called once per frame
	void Update () {
        if (Time < 0.0f || HitPoint <= 0)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);

        }
        else
            this.transform.localPosition += new Vector3(0, -0.02f, 0);
	}
}
