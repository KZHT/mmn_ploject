﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MediumbossStatus : MonoBehaviour {
    [SerializeField]
    public float MBossHitPoint = 1000;
    [SerializeField]
    private float Time = 3000.0f;
    [SerializeField]
    private float deltaTime = 1.0f;



    // Update is called once per frame
    void Update()
    {
        Time -= deltaTime;


        if (Time < 0.0f)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);

        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.CompareTag("Bom"))
        {
            MBossHitPoint -= 50;
        }

        if (collider.gameObject.CompareTag("ziki/shot"))
        {
            MBossHitPoint -= 10;
            FindObjectOfType<Score>().AddScore(10);
        }

        if (MBossHitPoint <= 0)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);
            FindObjectOfType<Score>().AddScore(1500);
        }
    }
}
