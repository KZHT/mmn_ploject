﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossStatus : MonoBehaviour
{
    [SerializeField]
   public  float BossHitPoint = 2000;
    [SerializeField]
    private float Time = 5000.0f;
    [SerializeField]
    private float deltaTime = 1.0f;



    // Update is called once per frame
    void Update()
    {
        Time -= deltaTime;


        if (Time < 0.0f)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);

        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.CompareTag("Bom"))
        {
            BossHitPoint -= 50;
        }

        if (collider.gameObject.CompareTag("ziki/shot"))
        {
            BossHitPoint -= 10;
            FindObjectOfType<Score>().AddScore(10);
        }

        if (BossHitPoint <= 0)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);
            FindObjectOfType<Score>().AddScore(5000);
        }
    }
	
}
