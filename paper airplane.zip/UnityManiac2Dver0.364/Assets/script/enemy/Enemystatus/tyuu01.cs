﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class tyuu01 : MonoBehaviour {
    [SerializeField]
    public float HitPoint = 60;
    [SerializeField]
    public float Time = 600.0f;
    [SerializeField]
    private float deltaTime = 1.0f;

    [SerializeField]
    GameObject Score;
    Text scorescript;
  


    void Update()
    {
        Time -= deltaTime;


        if (Time < 0.0f)
        {
             this.gameObject.transform.position = new Vector3(6.0f, 6.0f);   
        }
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.CompareTag("Bom"))
        {
            HitPoint -= 50;
        }

        if (collider.gameObject.CompareTag("ziki/shot"))
        {
            HitPoint -= 10;
            FindObjectOfType<Score>().AddScore(10);
        }

        if (collider.gameObject.CompareTag("UI"))
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);
        }

        if (HitPoint <= 0)
        {
            this.gameObject.transform.position = new Vector3(6.0f, 6.0f);
            FindObjectOfType<Score>().AddScore(500);
        }
    }
	
}
