﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour {

     private float Time = 600.0f;
     private float deltaTime = 1.0f;
     private bool instcnt = false;
     

	// Update is called once per frame
    void Update () {
        Time -= deltaTime;
        if (Time < 0.0f)
        {

            this.gameObject.tag = "Enemy";
           // this.gameObject.transform.position = new Vector3(6.0f, 6.0f);
            this.gameObject.SetActive(false);
        }

        

    }
}
