﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cinderellaamber : MonoBehaviour {

    //int objEnemy;
    //int dx_scr = 0;
    //int level = 

	/*// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}*/
}
