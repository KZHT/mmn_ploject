﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sample : MonoBehaviour {
    int objEnemy;
    int dx_scr = 0;
    //int level = GetCommonData("Level", 1);
    int x_enemy = 0;
    int y_enemy = 0;
    int vx_enemy = 0;
    int vy_enemy = 0;
    int xe = 0;
    int ye = 0;

    float BossScale = 1.0f;
    int istage = 1;

}
