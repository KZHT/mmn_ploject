﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnemyView : MonoBehaviour 
{
    
    [SerializeField]GameObject SpriteObject;
   
    public void SetModel(EnemyModel enemyModel)
    {
               var sprite = Resources.Load<GameObject>(string.Format("Enemy/{0}", enemyModel.AssetName));
        Debug.Log(sprite);
       
        SpriteObject = sprite;
        Instantiate(SpriteObject);
       
        
        Debug.Log("EnemyViewSetModel通過");
    }

}
