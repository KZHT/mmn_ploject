﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class StageView : MonoBehaviour 
{
    [SerializeField]GameObject SpriteStage;
    [SerializeField] EnemyView enemyViewPrefab;
    [SerializeField] Transform EnemySpawnPoint; //予め調整されたモンスターの出現位置を保持
    //Transform EnemySpawnPoint

    StageView spawnStage = null;
    EnemyView spawnedEnemy = null;
  [SerializeField]GameObject SpriteObject = null;

    //ステージ生成
    public void SetModel(StageModel stageModel)
    {
        //StageModelのAssetNameからステージオブジェクトを読み込み表示する
        var sprite = Resources.Load<GameObject>(string.Format("Stages/{0}", stageModel.AssetName));
        SpriteStage = sprite;
        Instantiate(SpriteStage);
              
    }



    //指定されたEnemyModelのシーンオブジェクトを生成する
    public GameObject SpawnEnemy(EnemyModel enemyModel,PosModel posModel)
    {
        var posspritex = Resources.Load<Transform>(string.Format("Spawnpos/{0}", posModel.Spawnpos));
         

        var sprite = Resources.Load<GameObject>(string.Format("Enemy/{0}", enemyModel.AssetName));
        //Debug.Log(sprite);
        //Debug.Log(posspritex);

        EnemySpawnPoint = posspritex;
        SpriteObject = sprite;

        //座標セット
        SpriteObject.transform.position = EnemySpawnPoint.transform.position;
       
        //敵生成
        Instantiate(SpriteObject);
        //SpriteObject.transform.SetParent(EnemySpawnPoint, false);
       
        Debug.Log(EnemySpawnPoint.transform.position.x);
        return SpriteObject;

         //EnemyModelのAssetNameから敵オブジェクトを読み込み表示する
        //GameObjectを読み込むならタグ(tag)でやれば通れる？
    }


}
