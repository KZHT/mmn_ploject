﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class ModelLoadAndSaveUseCase 
{

    UserRepository userRepository;
    MasterDataRepository masterDataRepository;
    UserModel userModel;


    public ModelLoadAndSaveUseCase()
    {
        //マスターデータへアクセスできるMasterDataRepositoryをロード
        masterDataRepository
            = Resources.Load<MasterDataRepository>("MasterDataRepository");

        userRepository = new UserRepository();
    }

    public UserModel GetUser()
    {
        var userEntity = userRepository.Get();

        if (userEntity == null)
        {
            //Entityを取得できなかった場合は新規に作成
            return new UserModel();
        }
        else
        {
            var user = new UserModel(userEntity);

            //Userがゲームオーバー状態であれば復帰させる
            if (user.IsDead) user.Restart();
            return user;
        }
    }
    
    //UserModelをEntityに変換し保存
    public void PutUser(UserModel user)
    {
        userRepository.Put(user.ToEntity());
    }

    //指定MstStageIdからモンスターを抽選しEnemyModelを生成
    public EnemyModel GetNextEnemy(int mstStageId,  int nextframe)
    {
        

        // Debug.Log("GetNextEnemy");
        //ステージとモンスターの関連データを取得
        List<MstpatternEntity> PatternCandidates
          = masterDataRepository.GetAllMstpatterns(mstStageId,nextframe);
         
        
        MstpatternEntity CntEnemy
            = PatternCandidates[nextframe/10]; //←ここに調整 行２は0から始まる
        
       
            //関連データからEnemyEntityを取得
            MstenemybookEntity mstEnemyEntity    //CntEnemy.cnt mstpatternEntity.mstEnemyId
               = masterDataRepository.GetMstEnemy(CntEnemy.mstEnemyId);

            
            //EnemyModelを生成
            return new EnemyModel(mstEnemyEntity);
      
    }

    //敵の出現する際の座標
    public PosModel GetNextPos(int mstStageId, int nextframe)
    {

        // Debug.Log("GetNextEnemy");
        //ステージとモンスターの関連データを取得
        List<MstpatternEntity> PatternCandidates
            = masterDataRepository.GetAllMstpatterns(mstStageId,nextframe);


        //出現モンスターの調整
        MstpatternEntity CntEnemy
            = PatternCandidates[nextframe/10]; 

        return new PosModel(CntEnemy);

    }

    public StageModel GetStage(int mstStageId)
    {
        //通った
        //Debug.Log(mstStageId);
       
        //エラー発生↓
        var stageEntity = masterDataRepository.GetMstStage(mstStageId);
        var nextStageEntity = masterDataRepository.GetMstStage(mstStageId + 1);
      //Debug.Log(stageEntity);
       
        
        //次のステージがあるかをチェックしStageModelに渡す
        
        return new StageModel(stageEntity, nextStageEntity != null);
    }


}
