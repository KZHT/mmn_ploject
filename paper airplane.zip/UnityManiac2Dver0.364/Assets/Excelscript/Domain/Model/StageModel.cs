﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StageModel 
{

    public int MstStageId { get; private set; }
    public string Name { get; private set; }
    public string AssetName { get; private set; }
    public long BossFrame { get; private set; }
    public bool IsExistsNextStage { get; private set; }

    public StageModel(MstStageEntity entity, bool isExstsNextStage)
    {
        //Entityからモデル内の値を設定する
        MstStageId = entity.id;
        Name = entity.name;
        AssetName = entity.assetName;
        BossFrame = entity.bossframe;
        IsExistsNextStage = isExstsNextStage;

    }
}
