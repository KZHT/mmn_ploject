﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyModel  {
    public string Name { get; private set; }
    public string AssetName { get; private set; }

    public int EmShot { get; private set; }
    public int HitPointEn { get; private set; }
    public int MaxHitPointEn { get; private set; }
    public int Item { get; private set; }

    public EnemyModel(MstenemybookEntity mstEnemyEntity)
    {
        //Entityからモデル内の実データを設定する
        Name = mstEnemyEntity.name;
        AssetName = mstEnemyEntity.assetName;
        
        //仕様変更あり(?)
        //自分の残機の所持数で敵のHP増加
        EmShot = mstEnemyEntity.emshot;
        MaxHitPointEn = mstEnemyEntity.hp;
        //MaxHitPointEn = Formula.EnhancedValue(mstEnemyEntity.hp, level);
        Item = mstEnemyEntity.item;

        HitPointEn = MaxHitPointEn;
    }

    public void Dmage(int damage)
    {
        //ダメージ値によるHitPointEnの減算、0以下にならないように切り詰める
        HitPointEn = (int)Mathf.Clamp(HitPointEn - damage, 0, MaxHitPointEn);
    }

    public bool IsDead
    {
        get
        {

            return HitPointEn <= 0;
        }

    }

}
