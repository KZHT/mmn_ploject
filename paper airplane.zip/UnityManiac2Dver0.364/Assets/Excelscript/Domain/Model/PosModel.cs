﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PosModel {
    public int Spawnpos { get; set; }


    public PosModel(MstpatternEntity mstPatternEntity)
    {
    //Entityからモデル内の実データを設定する
        Spawnpos = mstPatternEntity.spawnpos;
       
    }

}
