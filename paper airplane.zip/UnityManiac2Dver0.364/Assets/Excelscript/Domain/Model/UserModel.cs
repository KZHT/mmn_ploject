﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class UserModel {

    //各パラメータは120LVほどで桁が溢れてしまうので本来はlongにすべき、現状LV120を越えるとバグる
    const int BaseHitPoint = 120;
    const int BaseAttack = 10;
    const int BaseStamina = 1;
    const int BaseEnhancePoint = 5;

    //Monsterモデルと同じダメージ計算式を利用するため、定数として保持
    public const int Defence = 1;

    public int HitPoint; //{ get; public set; }
    public int MaxHitPoint { get; private set; }
    public int SkillPoint { get; private set; }
    public int Attack { get; private set; }
    public int Stamina { get; private set; }
   
    public int InProgressStageId { get; private set; }

    public int InProgressFrameCount { get; private set; }  //イントじゃないlongや
  //public int InProgressFrameCount;  //イントじゃないlongや
    public int CurrentStageId { get; private set; }

    int hitPointLevel;
    int attackLevel;
    int staminaLevel;

    DateTime lastHealAt;
    double healPoint;

    public UserModel(UserEntity entity)
    {
        //Entityからモデル内の実データを設定する
        InProgressStageId = entity.inProgressStageId;
        InProgressFrameCount = entity.inProgressStageFrameCount;
        CurrentStageId = entity.currentStageId;

        HitPoint = entity.hitPoint;
        SkillPoint = entity.skillPoint;

        hitPointLevel = entity.hitPointLevel;
        attackLevel = entity.attackLevel;
        staminaLevel = entity.staminaLevel;

        //Entity内で時間データはstringであるため、パースすることで実体を得る
        lastHealAt = DateTime.Parse(entity.lastHealAt);

        //設定したパラメータのレベル値から実際の値を更新
        
    }

    //引数がない場合は初期データとして生成
    public UserModel() : this(
        new UserEntity()
        {
            inProgressStageId = 1,
            currentStageId = 1, //1
            inProgressStageFrameCount = 0,
            hitPointLevel = 1,
            attackLevel = 1,
            staminaLevel = 1,
            hitPoint = BaseHitPoint,
            skillPoint = 0,

            //時間経過で敵出現あり
            lastHealAt = System.DateTime.Now.ToString()
        }
        ){}

    void UpdateParameter()
    {
        //各パラメータの現在レベルに応じて、実際の値を計算
        MaxHitPoint = Formula.EnhancedValue(BaseHitPoint, hitPointLevel);
        Attack = Formula.EnhancedValue(BaseAttack, attackLevel);
        Stamina = Formula.EnhancedValue(BaseStamina, staminaLevel);
    }

   


    public void Damage(int damage)
    {
        //ダメージ値によるHitPointの減算、0以下にならないように切り詰める
        HitPoint = (int)Mathf.Clamp(HitPoint - damage, 0, MaxHitPoint);
    }

    public bool IsDead
    {
        get
        {
            return HitPoint <= 0;
        }
    }

    //現在滞在中のステージが最前線かどうかを返却
    public bool IsInProgressStage
    {
        get
        {
            return CurrentStageId == InProgressStageId;
        }
    }

    //最終回復時間から経過秒数に応じてHitPointの回復をおこなう
    public void Heal()
    {
        TimeSpan span = DateTime.Now - lastHealAt;

        //上限なく秒数を計測すると桁溢れを起こすため、理論的な上限値で切り詰める
        float maxSeconds = Mathf.Ceil((float)MaxHitPoint / Stamina);
        double healSeconds = span.TotalSeconds < maxSeconds ? span.TotalSeconds : maxSeconds;

        healPoint += healSeconds * Stamina;

        //回復量が1に満たない場合は何もしない
        if (healPoint > 1)
        {
            //整数部をHitPointに移し替える
            int actualHeal = (int)healPoint;
            healPoint -= actualHeal;

            //回復量の加算、MaxHitPointを越えないように切り詰め
            HitPoint = (long)HitPoint + actualHeal < MaxHitPoint ? HitPoint + actualHeal : MaxHitPoint;
        }

        lastHealAt = DateTime.Now;
        //Debug.Log("ヒール完了");
    }

    public void Framecnt()
    {
        InProgressFrameCount++;
       // Debug.Log(InProgressFrameCount);

    }

    public void NextStage()
    {
        CurrentStageId++;
        InProgressFrameCount = 0;
    }

    public void BackStage()
    {
        //ステージを戻った場合は、討伐数をリセットする
        CurrentStageId--;

        InProgressFrameCount = 0; //変更あり
    }

    //ゲームオーバー時の処理
    public void Restart()
    {
        //最前線の攻略データをリセット
        InProgressFrameCount = 0;
        CurrentStageId = 1;

        //ペナルティとして各能力レベルを下げる
        if (hitPointLevel > 1) hitPointLevel--;
        if (attackLevel > 1) attackLevel--;
        if (staminaLevel > 1) staminaLevel--;
        UpdateParameter();

        HitPoint = MaxHitPoint / 2;
        lastHealAt = DateTime.Now;
    }

    public int RequiredHitPointSP
    {
        get
        {
            return Formula.EnhancedValue(BaseEnhancePoint, hitPointLevel);
        }
    }

    public int RequiredAttackSP
    {
       get
       {
           return Formula.EnhancedValue(BaseEnhancePoint, attackLevel);
       }

    }

    public int RequiredStaminaSP
    {
        get
        {
            return Formula.EnhancedValue(BaseEnhancePoint, staminaLevel);
        }
    }
    /*
    // モンスターに攻撃を実行
    public int AttackToMonster(MonsterModel monster, StageModel stage)
    {
        int damage = Formula.DamageValue(Attack, monster.Defence);
        monster.Damage(damage);

        // モンスターを討伐したら、スキルポイントの付与等の処理をおこなう
        if (monster.IsDead)
        {
            SkillPoint += monster.DropSkillPoint;

            // 最前線ステージの場合、討伐数の更新、攻略ステージの更新をおこなう
            if (IsInProgressStage)
            {
                InProgressKillCount++;
                if (InProgressKillCount >= stage.RequiredKillCount) CompleteInProgressStage();
            }
        }

        return damage;
    }*/

    // 現在モデルが保持しているデータをEntityに変換する
    public UserEntity ToEntity()
    {
        return new UserEntity()
        {
            inProgressStageId = InProgressStageId,
            currentStageId = CurrentStageId,                  //コピペエラー
            inProgressStageFrameCount = InProgressFrameCount, //コピペエラー
            hitPointLevel = hitPointLevel,
            attackLevel = attackLevel,
            staminaLevel = staminaLevel,
            hitPoint = HitPoint,
            skillPoint = SkillPoint,
            lastHealAt = lastHealAt.ToString()
        };
    }

}
