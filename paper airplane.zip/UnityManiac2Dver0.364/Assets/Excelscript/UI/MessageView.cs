﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class MessageView : MonoBehaviour {

    [SerializeField]Text messageText;
    [SerializeField]Button butoon;

    Action completion;

    void Awake()
    {
        butoon.onClick.AddListener(OnOk);
    }

    string Message
    {
        set
        {
            messageText.text = value;
        }

    }


    //指定メッセージを表示し、ユーザの入力を待ち受ける
    public void Show(string message, Action completion)
    {
        Message = message;
        gameObject.SetActive(true);
        this.completion = completion;
    }

    void OnOk()
    {
        var action = completion;
        completion = null;
        gameObject.SetActive(false);
        action();
    }
}
