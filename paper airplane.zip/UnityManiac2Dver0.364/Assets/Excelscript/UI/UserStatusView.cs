﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UserStatusView : MonoBehaviour {
  /*  [SerializeField] Text hitPointText;
    [SerializeField] Slider hitPointSlider;
    //Slider hitPointSlider;
    int maxHitPoint = 1;

    UserModel userModel;

    public void ObserveModel(UserModel userModel)
    {
        this.userModel = userModel;
    }

    void Update()
    {
        if (userModel == null) return;

        //UserModelを監視しUIに反映させる
        maxHitPoint = userModel.MaxHitPoint;
        HitPoint = userModel.HitPoint;

    }

    int HitPoint
    {
        set
        {

            //hitPointText.text = string.Format("HP:{0}/{1}", value, maxHitPoint);
            hitPointText.text = string.Format("HP:{0}", value, maxHitPoint);
            hitPointSlider.value = (float)value / maxHitPoint;
        }

    }*/

}
