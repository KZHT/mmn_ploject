﻿using System.Collections;
using UnityEngine;

public class ClashCameraEffect : MonoBehaviour {

    public void Clash()
    {
        GetComponent<Animator>().SetTrigger("shake");
    }
	
}
