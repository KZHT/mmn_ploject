﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StageInfoView : MonoBehaviour {

    [SerializeField]Text stageNameText;
    [SerializeField]Text frameCnt;
    [SerializeField]Text BossCnt;
    [SerializeField]Text comp;


    StageModel stageModel;
    UserModel user;

    public void ObserveModel(StageModel stageModel, UserModel userModel)
    {
        this.stageModel = stageModel;
        this.user = userModel;
    }

    void Update()
    {
        if (stageModel == null || user == null) return;

        //Modelを監視しUIに反映させる
        SetStageName(stageModel.MstStageId, stageModel.Name);
        SetBossCount(stageModel.BossFrame);

        //現在のフレーム数を表示する
        if (user.IsInProgressStage) SetFrameCount(user.InProgressFrameCount);
        else SetAsStageCompleted();


    }

    void SetStageName(int depth, string name)
    {
        stageNameText.text = string.Format("{1}", depth, name);
    }

    void SetFrameCount(long frame)
    {
        frameCnt.text = string.Format("{0}", frame);
    }

    void SetBossCount(long frame)
    {
        BossCnt.text = string.Format("{0}", frame);
    }

    void SetAsStageCompleted()
    {
        comp.text = "Completed";
    }

}
