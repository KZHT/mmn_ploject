﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Presenter1 : Excelcnt {

    [SerializeField]
    UserStatusView userStatusView;
    [SerializeField]
    StageInfoView stageInfoView;
    [SerializeField]
    MessageView messageView;

    [SerializeField]
    StageView stageView;
    [SerializeField]
    ClashCameraEffect cameraEffect;

    ModelLoadAndSaveUseCase useCase;

    UserModel  userModel;
    StageModel stageModel;
    EnemyModel enemyModel;
    PosModel   posModel;

    EnemyView        enemyView;
    MstpatternEntity mstpatternentity;
    Excelcnt         excelcnt;

    int nextframe ;

    int frame =0;
    int frame2 = 0;

    int[] stageEnemy1 = {10, 20, 30, 40, 50,
                           60, 70, 80, 90, 100,
                           110, 120,130,140,150};


    void Start() 
    {
        useCase = new ModelLoadAndSaveUseCase();

        //UserModelの取得
        userModel = useCase.GetUser();

        //UserModelの回復やデータ保存制御をスタートさせる
        UserModelHandler.Create(userModel, useCase);

        //各UIの初期化
        //userStatusView.ObserveModel(userModel);


        SetupStage();

    }

    void Update()
    {

        if (frame == 10) 
        {
            if (frame2 == stageEnemy1[nextframe])
        {
            //userModel.InProgressFrameCount
            Debug.Log("生成した！");
            Debug.Log(stageEnemy1[nextframe]);
            enemyModel = useCase.GetNextEnemy(stageModel.MstStageId, stageEnemy1[nextframe]);
            posModel = useCase.GetNextPos(stageModel.MstStageId, stageEnemy1[nextframe]);

            stageView.SpawnEnemy(enemyModel, posModel);

            nextframe++;
            frame2++;
        }
        else { frame2++; }
        frame = 0;
        }
        else
        {
            frame++;
        }

    }

    void SetupStage()
    {
        //UserのデータからステージとモンスターのModelを生成
        stageModel = useCase.GetStage(userModel.CurrentStageId);

        //Modelからシーン上のオブジェクトを初期化
        stageView.SetModel(stageModel);

        //ModelからUIを初期化
        stageInfoView.ObserveModel(stageModel, userModel);
    }

    void OnBackStage()
    {
        userModel.BackStage();
        frame =0;
        frame2 =0;
        nextframe = 0;
    }

    void OnNextStage()
    {
        if(!stageModel.IsExistsNextStage)
        {
            messageView.Show("All Completed!", () => { });
            return;
        }
        userModel.NextStage();
        SetupStage();
        frame++;
        frame2++;
        nextframe = 0;
    }

}
