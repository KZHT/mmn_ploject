﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UserModelHandler : MonoBehaviour {
    UserModel userModel;
    ModelLoadAndSaveUseCase useCase;

    public static UserModelHandler Create(UserModel userModel, ModelLoadAndSaveUseCase useCase)
    {
        var go = new GameObject("UserModelHandler");
        var userModelHandler = go.AddComponent<UserModelHandler>();
        userModelHandler.userModel = userModel;
        userModelHandler.useCase = useCase;
        return userModelHandler;
    }

    void Update()
    {
        //毎フレーム回復処理を行う
        if (!userModel.IsDead) userModel.Heal();

        userModel.Framecnt();

    }
    /*
    // シーンが中断、終了したタイミングを検知しUserデータの保存をおこなう 
    void OnApplicationPause(bool isPaused)
    {
        if (isPaused) PutData();
    }

    void OnDestroy()
    {
        PutData();
    }

    void PutData()
    {
        useCase.PutUser(userModel);
    }*/

}
