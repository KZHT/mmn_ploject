﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Formula  {

    public static int EnhancedValue(int baseValue, int level)
    {
        //レベルが上がる度にベース値を1.15倍する計算
        float value = baseValue * Mathf.Pow(1.15f, level - 1);

        //レベルが上がれば必ず1ポイントは上昇するように補正
        return (int)Mathf.Max(baseValue + (level - 1), value);

    }

    public static int DamageValue(int attack, int defence)
    {
        int value = (attack - defence) / 2;

        //最低でも1ポイントはダメージを受けるようにする
        return (int)Mathf.Clamp(value, 1, value);
    }

}
