﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Excelcnt : MonoBehaviour {

  public int[] stageEnemy;
  
  public int[] stageEnemy2 = { 300, 301, 302,303, 304,
                             700, 800, 900, 1000, 1100,
                             1200, 1300
                              };

}
