﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Presenter : Excelcnt {
    //MonoBehaviour

     [SerializeField] UserStatusView userStatusView;
     [SerializeField] StageInfoView stageInfoView;
    // [SerializeField] DamageView menuView;
    // [SerializeField] MenuView menuView;
     [SerializeField] MessageView messageView;
      
     [SerializeField] StageView stageView;
     [SerializeField]ClashCameraEffect cameraEffect;


    ModelLoadAndSaveUseCase useCase;

    UserModel userModel;
    StageModel stageModel;
    EnemyModel enemyModel;
    PosModel posModel;

    EnemyView enemyrView;
    MstpatternEntity mstpateernentity;
    Excelcnt excelcnt;

    public int[] stageEnemy1 =  {300, 350, 400,450, 500,
                             700, 800, 900, 1000, 1100,
                             1200, 1300};

    [SerializeField]
   public int cnt = 0;
    [SerializeField]
   public int nextframe = 0;
   
    void Start()
    {
        
        useCase = new ModelLoadAndSaveUseCase();

        //UserModelの取得
        userModel = useCase.GetUser();

        //UserModelの回復やデータ保存制御をスタートさせる
        UserModelHandler.Create(userModel, useCase);


        //各UIの初期化
       // userStatusView.ObserveModel(userModel);


        SetupStage();
        
    }

    void Update()
    {
         
      /*  //Enemy生成
        if (userModel.InProgressFrameCount == stageEnemy1[nextframe])
        {
            Debug.Log("生成した！");
           
            enemyModel = useCase.GetNextEnemy(stageModel.MstStageId, userModel.InProgressFrameCount, stageEnemy1[nextframe]);
            posModel = useCase.GetNextPos(stageModel.MstStageId, userModel.InProgressFrameCount, stageEnemy1[nextframe]);

            stageView.SpawnEnemy(enemyModel, posModel); 
           
            nextframe++;
            Debug.Log(stageEnemy1[nextframe]);
         }*/

        /*if (cnt == stageEnemy1[nextframe])
        {
            Debug.Log("生成した！");
            Debug.Log(stageEnemy1[nextframe]);
            enemyModel = useCase.GetNextEnemy(stageModel.MstStageId, userModel.InProgressFrameCount, stageEnemy1[nextframe]);
            posModel = useCase.GetNextPos(stageModel.MstStageId, userModel.InProgressFrameCount, stageEnemy1[nextframe]);

            stageView.SpawnEnemy(enemyModel, posModel);
            Debug.Log(stageEnemy1[nextframe]);
            nextframe++;
           // Debug.Log(stageEnemy1[nextframe]);
         }
        cnt++;*/

        if(nextframe == stageEnemy1[cnt])
        {
            Debug.Log(nextframe);
            Debug.Log(stageEnemy1[cnt]);
            cnt++;
        }
        nextframe++;
    }

    void SetupStage()
    {

       /* switch (userModel.CurrentStageId)
        {
            case 1:
                stageEnemy = stageEnemy1;
                break;

            case 2:
                stageEnemy = stageEnemy2;
                break;

            case 3:
                break;
        }*/

        //UserのデータからステージとモンスターのModelを生成
        stageModel = useCase.GetStage(userModel.CurrentStageId);
        
       
        //Modelからシーン上のオブジェクトを初期化
        stageView.SetModel(stageModel);

        //ModelからUIを初期化
        stageInfoView.ObserveModel(stageModel, userModel);
        
    }


    void OnBackStage()
    {
        userModel.BackStage();
        nextframe = 0;
    }

    void OnNextStage()
    {
        if (!stageModel.IsExistsNextStage)
        {
            messageView.Show("All Completed!", () => { });
            return;
        }
        userModel.NextStage();
        SetupStage();
        nextframe = 0;
    }
    
}
