using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExcelAsset]
public class Mstpattern : ScriptableObject
{
	public List<MstpatternEntity> Entities; 
}
