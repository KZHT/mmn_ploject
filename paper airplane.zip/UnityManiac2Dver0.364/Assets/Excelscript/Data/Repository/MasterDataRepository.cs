﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class MasterDataRepository : ScriptableObject 
{
    
    [SerializeField]
    Mstenemybook MstEnemybook;

    [SerializeField]
    MstStage stages;

    [SerializeField]
    Mstpattern MstPattern;
                                             //↓　idからCntに変換
    public MstenemybookEntity GetMstEnemy(int id)
    {
        return MstEnemybook.Entities.Find(entity => entity.id == id);
    }

    public MstStageEntity GetMstStage(int id)
    {
       //Debug.Log("MstStage読み込み完了");
        return stages.Entities.Find(entity => entity.id == id);
    }

    public MstpatternEntity GetMstCnt(double nextframe)
    {

        return MstPattern.Entities.Find(entity => entity.cnt == nextframe);
    }

    //ステージIdをキーにして検索したモンスターの出現テーブルデータを取得
    public List<MstpatternEntity> GetAllMstpatterns(int mstStageId,int nextframe)
    {
             //  MstPattern.Entities.FindAll(entity => entity.cnt == nextframe);
        return MstPattern.Entities.FindAll(entity => entity.mstStageId == mstStageId);
    }
    
}
