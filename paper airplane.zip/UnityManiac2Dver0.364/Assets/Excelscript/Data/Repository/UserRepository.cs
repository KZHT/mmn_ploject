﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class UserRepository {

    static string EntityPath
    {
        get
        {
            //UserRntityファイルはアプリケーションの永続化領域に保持される
            return Path.Combine(Application.persistentDataPath, "UserEntity.json");
        }

    }
	
    public bool IsExists()
    {
        return File.Exists(EntityPath);
    }

    //保持されているユーザデータをロード、取得できなかった場合はnull返す
   public UserEntity Get()
    {
      if(!IsExists()) return null;
    
    try{
     string json = File.ReadAllText(EntityPath);
     return JsonUtility.FromJson<UserEntity>(json);
    }
    catch{
    
    return null;
    }
    
    }
    

    //UserEntityをJsonにて書き出す
    //サンプルにて簡易だが、実際にはエラーハンドリング、暗号化等が必要
    public void Put(UserEntity entity)
    {
        string json = JsonUtility.ToJson(entity);
        File.WriteAllText(EntityPath, json);
    }
#if UNITY_EDITOR
    //UnityEditorのメニューからUserEntity.jsonの表示が可能
    [UnityEditor.MenuItem("Assets/Reval User Entity")]
    static void RevaInFinder(){
       UnityEditor.EditorUtility.RevealInFinder(EntityPath);
    }
#endif
}
