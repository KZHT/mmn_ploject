﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class UserEntity  {

    public int inProgressStageId; //現在の最前線ステージId
    public int inProgressStageFrameCount; //最前線ステージにおける経過数
    public int currentStageId; //現在滞在中のステージId;

    public int hitPoint;   //現在ヒットポイント
    public int skillPoint; //現在スキルポイント

    public int hitPointLevel; //ヒットポイントレベル
    public int attackLevel;  //攻撃レベル
    public int staminaLevel; //スタミナレベル

    public string lastHealAt; //最終回復時間
}
