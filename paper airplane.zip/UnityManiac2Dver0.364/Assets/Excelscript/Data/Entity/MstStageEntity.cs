﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class MstStageEntity {

    public int id;   //呼び出すモンスターのid
    public string name;      //ステージ名
    public string assetName; //ステージ画像のアセット名   
    public long bossframe; //ボスを呼び出す時のフレーム
}
