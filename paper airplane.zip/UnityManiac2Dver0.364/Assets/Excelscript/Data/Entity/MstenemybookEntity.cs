﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class MstenemybookEntity 
{

    public int id; //id
    public string name;//モンスターの名称
    public string assetName;//モンスター画像アセット名
    public int emshot;//敵のショットのパターン
    public int hp;    //敵のHP
    public int item;  //敵を倒したときのアイテム(数字)

}
