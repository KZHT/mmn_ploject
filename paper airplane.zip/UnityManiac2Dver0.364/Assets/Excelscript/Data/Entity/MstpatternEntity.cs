﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class MstpatternEntity {

    public int id;        //出現テーブルデータのId
    public int mstStageId;//ステージId
    public int mstEnemyId;//出現するモンスターId
    public double cnt;       //出力するときのカウント
    public int spawnpos;
}
